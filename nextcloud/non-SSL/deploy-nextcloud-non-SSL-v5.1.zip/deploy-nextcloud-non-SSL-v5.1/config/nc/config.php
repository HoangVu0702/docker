<?php
$CONFIG = array (
  'overwriteprotocol' => 'http',
  'forwarded_for_headers' => ['HTTP_X_FORWARDED', 'HTTP_FORWARDED_FOR'],
  'overwrite.cli.url' => 'http://$domain/',
  'htaccess.RewriteBase' => '/',
  'memcache.local' => '\\OC\\Memcache\\APCu',
  'apps_paths' => 
  array (
    0 => 
    array (
      'path' => '/var/www/html/apps',
      'url' => '/apps',
      'writable' => false,
    ),
    1 => 
    array (
      'path' => '/var/www/html/custom_apps',
      'url' => '/custom_apps',
      'writable' => true,
    ),
  ),
  'passwordsalt' => 'a7tb2CgiyMfEb3EW3CI1ypoc7N0eZ3',
  'secret' => 'T4lym9lI7v9xYYEDlKlrp5vP5I5lQKWyCaUISWymTq2YZy9Y',
  'trusted_domains' => 
  array (
    0 => 'localhost',
    1 => '$domain',
    2 => '$domain1',
    3 => '$ip',
  ),
  'datadirectory' => '/var/www/html/data',
  'dbtype' => 'mysql',
  'version' => '27.1.1.0',
  // 'overwrite.cli.url' => 'http://localhost',
  'dbname' => 'nextcloud',
  'dbhost' => '192.168.100.100',
  'dbport' => '',
  'dbtableprefix' => 'oc_',
  'mysql.utf8mb4' => true,
  'dbuser' => 'nextcloud',
  'dbpassword' => '$59Yo44L&tXKXyDy',
  'installed' => true,
  'instanceid' => 'ocs9jvgdei11',
);
